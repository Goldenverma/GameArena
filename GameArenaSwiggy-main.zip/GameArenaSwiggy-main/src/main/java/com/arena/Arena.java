package com.arena;

public class Arena {
    private Player playerA;
    private Player playerB;
    private Dice dice;

    public Arena(Player playerA, Player playerB) {
        this.playerA = playerA;
        this.playerB = playerB;
        this.dice = new Dice();
    }

    public void fight() {
        System.out.println("Fight starts between " + playerA.getName() + " and " + playerB.getName());

        while (playerA.isAlive() && playerB.isAlive()) {
            if (playerA.getHealth() < playerB.getHealth()) {
                attack(playerA, playerB);
                if (playerB.isAlive()) {
                    attack(playerB, playerA);
                }
            } else {
                attack(playerB, playerA);
                if (playerA.isAlive()) {
                    attack(playerA, playerB);
                }
            }
        }

        if (playerA.isAlive()) {
            System.out.println(playerA.getName() + " wins the fight!");
        } else {
            System.out.println(playerB.getName() + " wins the fight!");
        }
    }

    private void attack(Player attacker, Player defender) {
        int attackRoll = dice.roll();
        int defenseRoll = dice.roll();
        int attackDamage = attacker.getAttack() * attackRoll;
        int defenseDamage = defender.getStrength() * defenseRoll;

        int damage = attackDamage - defenseDamage;

        if (damage > 0) {
            defender.reduceHealth(damage);
            System.out.println(attacker.getName() + " attacks " + defender.getName() + " and deals " + damage + " damage.");
            System.out.println(defender.getName() + " health is now " + defender.getHealth());
        } else {
            System.out.println(defender.getName() + " defends the attack successfully.");
        }
    }
}
