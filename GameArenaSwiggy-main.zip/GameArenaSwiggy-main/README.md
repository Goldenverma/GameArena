
# Magical Arena

This project simulates a magical arena where two players fight until one of them dies.

## How to Run

1. Clone the repository.
2. Navigate to the project directory.
3. Compile the Java files:
   ```sh
   javac *.java
   ```
4. Run the main class:
   ```sh
   java Main
   ```

## Unit Tests

To run the unit tests, ensure you have JUnit 5 set up. You can use your IDE to run the tests or use the following command if you have `javac` and `java` setup for JUnit:

```sh
javac -cp .:junit-platform-console-standalone-1.8.1.jar *.java
java -jar junit-platform-console-standalone-1.8.1.jar --class-path . --scan-class-path
```

## Design Considerations

- The `Player` class encapsulates player attributes and behaviors.
- The `Dice` class simulates a 6-sided dice.
- The `Arena` class manages the fight between two players.
- The `Main` class initializes the players and starts the fight.
- The code is organized for readability and maintainability.
- Unit tests cover the essential functionality and ensure the code works as expected.

# Game Design

## Classes Overview

### Player
Represents a player in the game with attributes and methods related to their state and actions.

- **Attributes:**
  - `name: String` - The name of the player.
  - `health: int` - The current health of the player.
  - `strength: int` - The strength of the player.
  - `attack: int` - The attack power of the player.

- **Methods:**
  - `getName(): String` - Returns the name of the player.
  - `getHealth(): int` - Returns the current health of the player.
  - `reduceHealth(damage: int)` - Reduces the player's health by the specified damage amount.
  - `getStrength(): int` - Returns the strength of the player.
  - `getAttack(): int` - Returns the attack power of the player.
  - `isAlive(): boolean` - Returns whether the player is alive based on their health.
  - `toString(): String` - Returns a string representation of the player.

### Dice
Represents a dice with a number of sides and methods to roll it.

- **Attributes:**
  - `SIDES: int` - The number of sides on the dice.
  - `random: Random` - The random number generator used to roll the dice.

- **Methods:**
  - `roll(): int` - Rolls the dice and returns a random number between 1 and the number of sides.

### Arena
Represents the arena where two players can fight.

- **Attributes:**
  - `playerA: Player` - The first player in the arena.
  - `playerB: Player` - The second player in the arena.
  - `dice: Dice` - The dice used in the fight.

- **Methods:**
  - `fight(): void` - Initiates a fight between `playerA` and `playerB`.
  - `attack(attacker: Player, defender: Player): void` - Handles an attack from the `attacker` player to the `defender` player.
